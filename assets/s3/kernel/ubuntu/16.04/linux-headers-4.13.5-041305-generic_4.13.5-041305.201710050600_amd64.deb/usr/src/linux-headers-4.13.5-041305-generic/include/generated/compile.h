/* This file is auto generated, version 201710050600 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201710050600 SMP Thu Oct 5 10:02:44 UTC 2017"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "gloin"
#define LINUX_COMPILER "gcc version 7.2.0 (Ubuntu 7.2.0-7ubuntu1)"
